-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: db_orgdocente
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_orgdocente`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_orgdocente` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `db_orgdocente`;

--
-- Table structure for table `docente_horario`
--

DROP TABLE IF EXISTS `docente_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docente_horario` (
  `doc_id` int(10) NOT NULL,
  `hor_id` int(10) NOT NULL,
  KEY `docente_horario` (`doc_id`),
  KEY `horario_docente` (`hor_id`),
  CONSTRAINT `docente_horario` FOREIGN KEY (`doc_id`) REFERENCES `tbl_docente` (`doc_id`),
  CONSTRAINT `horario_docente` FOREIGN KEY (`hor_id`) REFERENCES `tbl_horario` (`hor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docente_horario`
--

LOCK TABLES `docente_horario` WRITE;
/*!40000 ALTER TABLE `docente_horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `docente_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pensum_certificado`
--

DROP TABLE IF EXISTS `pensum_certificado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pensum_certificado` (
  `pens_id` int(10) NOT NULL,
  `cert_id` int(10) NOT NULL,
  KEY `pens_cert` (`pens_id`),
  KEY `cert_pens` (`cert_id`),
  CONSTRAINT `cert_pens` FOREIGN KEY (`cert_id`) REFERENCES `tbl_certificado` (`cert_id`),
  CONSTRAINT `pens_cert` FOREIGN KEY (`pens_id`) REFERENCES `tbl_malla` (`pens_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pensum_certificado`
--

LOCK TABLES `pensum_certificado` WRITE;
/*!40000 ALTER TABLE `pensum_certificado` DISABLE KEYS */;
/*!40000 ALTER TABLE `pensum_certificado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seccion_grupo`
--

DROP TABLE IF EXISTS `seccion_grupo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seccion_grupo` (
  `gro_id` int(10) NOT NULL,
  `sec_id` int(10) NOT NULL,
  KEY `grupo_seccion` (`gro_id`),
  KEY `seccion_grupo` (`sec_id`),
  CONSTRAINT `grupo_seccion` FOREIGN KEY (`gro_id`) REFERENCES `tbl_grupo` (`gro_id`),
  CONSTRAINT `seccion_grupo` FOREIGN KEY (`sec_id`) REFERENCES `tbl_seccion` (`sec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seccion_grupo`
--

LOCK TABLES `seccion_grupo` WRITE;
/*!40000 ALTER TABLE `seccion_grupo` DISABLE KEYS */;
/*!40000 ALTER TABLE `seccion_grupo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seccion_horario`
--

DROP TABLE IF EXISTS `seccion_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seccion_horario` (
  `sec_id` int(10) NOT NULL,
  `hor_id` int(10) NOT NULL,
  KEY `seccion_horario` (`sec_id`),
  KEY `horario_seccion` (`hor_id`),
  CONSTRAINT `horario_seccion` FOREIGN KEY (`hor_id`) REFERENCES `tbl_horario` (`hor_id`),
  CONSTRAINT `seccion_horario` FOREIGN KEY (`sec_id`) REFERENCES `tbl_seccion` (`sec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seccion_horario`
--

LOCK TABLES `seccion_horario` WRITE;
/*!40000 ALTER TABLE `seccion_horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `seccion_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_area`
--

DROP TABLE IF EXISTS `tbl_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_area` (
  `area_id` int(10) NOT NULL AUTO_INCREMENT,
  `area_nombre` varchar(30) NOT NULL,
  `area_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_area`
--

LOCK TABLES `tbl_area` WRITE;
/*!40000 ALTER TABLE `tbl_area` DISABLE KEYS */;
INSERT INTO `tbl_area` VALUES (1,'Desarrollo de Software',1),(2,'Proyectos Comunitarios',1);
/*!40000 ALTER TABLE `tbl_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_categoria`
--

DROP TABLE IF EXISTS `tbl_categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_categoria` (
  `cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_nombre` varchar(30) NOT NULL,
  `cat_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_categoria`
--

LOCK TABLES `tbl_categoria` WRITE;
/*!40000 ALTER TABLE `tbl_categoria` DISABLE KEYS */;
INSERT INTO `tbl_categoria` VALUES (1,'Instructor',1),(2,'Agregado',1);
/*!40000 ALTER TABLE `tbl_categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_certificado`
--

DROP TABLE IF EXISTS `tbl_certificado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_certificado` (
  `cert_id` int(10) NOT NULL AUTO_INCREMENT,
  `cert_estado` tinyint(1) NOT NULL,
  `tra_id` int(10) NOT NULL,
  `cert_nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`cert_id`),
  KEY `trayecto_certificado` (`tra_id`),
  CONSTRAINT `trayecto_certificado` FOREIGN KEY (`tra_id`) REFERENCES `tbl_trayecto` (`tra_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_certificado`
--

LOCK TABLES `tbl_certificado` WRITE;
/*!40000 ALTER TABLE `tbl_certificado` DISABLE KEYS */;
INSERT INTO `tbl_certificado` VALUES (1,1,3,'Técnico Superior en Informátic');
/*!40000 ALTER TABLE `tbl_certificado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_docente`
--

DROP TABLE IF EXISTS `tbl_docente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_docente` (
  `doc_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) NOT NULL,
  `doc_prefijo` char(1) NOT NULL,
  `doc_cedula` int(10) NOT NULL,
  `doc_nombre` varchar(30) NOT NULL,
  `doc_apellido` varchar(30) NOT NULL,
  `doc_correo` varchar(30) NOT NULL,
  `doc_dedicacion` enum('Dedicación exclusiva','Dedicación') NOT NULL,
  `doc_condicion` enum('Ordinario','Desordinario') NOT NULL,
  `doc_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`doc_id`),
  KEY `categoria_docente` (`cat_id`),
  CONSTRAINT `categoria_docente` FOREIGN KEY (`cat_id`) REFERENCES `tbl_categoria` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_docente`
--

LOCK TABLES `tbl_docente` WRITE;
/*!40000 ALTER TABLE `tbl_docente` DISABLE KEYS */;
INSERT INTO `tbl_docente` VALUES (1,1,'V',11223344,'Ana','Silva','ana.silva@email.com','Dedicación exclusiva','Ordinario',1),(2,2,'V',55667788,'Luis','Mora','luis.mora@email.com','Dedicación','',1);
/*!40000 ALTER TABLE `tbl_docente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_eje`
--

DROP TABLE IF EXISTS `tbl_eje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_eje` (
  `eje_id` int(10) NOT NULL AUTO_INCREMENT,
  `eje_nombre` varchar(30) NOT NULL,
  `eje_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`eje_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_eje`
--

LOCK TABLES `tbl_eje` WRITE;
/*!40000 ALTER TABLE `tbl_eje` DISABLE KEYS */;
INSERT INTO `tbl_eje` VALUES (1,'Profesional',1),(2,'Socio-Crítico',1);
/*!40000 ALTER TABLE `tbl_eje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_espacio`
--

DROP TABLE IF EXISTS `tbl_espacio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_espacio` (
  `esp_id` int(10) NOT NULL AUTO_INCREMENT,
  `esp_codigo` varchar(20) NOT NULL,
  `esp_tipo` enum('Aula','Laboratorio','','') NOT NULL,
  `esp_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`esp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_espacio`
--

LOCK TABLES `tbl_espacio` WRITE;
/*!40000 ALTER TABLE `tbl_espacio` DISABLE KEYS */;
INSERT INTO `tbl_espacio` VALUES (1,'A101','Aula',1),(2,'L201','Laboratorio',1);
/*!40000 ALTER TABLE `tbl_espacio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_grupo`
--

DROP TABLE IF EXISTS `tbl_grupo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_grupo` (
  `gro_id` int(10) NOT NULL AUTO_INCREMENT,
  `grupo_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`gro_id`),
  KEY `seccion_group` (`grupo_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_grupo`
--

LOCK TABLES `tbl_grupo` WRITE;
/*!40000 ALTER TABLE `tbl_grupo` DISABLE KEYS */;
INSERT INTO `tbl_grupo` VALUES (1,1);
/*!40000 ALTER TABLE `tbl_grupo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_horario`
--

DROP TABLE IF EXISTS `tbl_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_horario` (
  `hor_id` int(10) NOT NULL AUTO_INCREMENT,
  `esp_id` int(10) NOT NULL,
  `hor_fase` enum('1','2') NOT NULL,
  `hor_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`hor_id`),
  KEY `espacio_horario` (`esp_id`),
  CONSTRAINT `espacio_horario` FOREIGN KEY (`esp_id`) REFERENCES `tbl_espacio` (`esp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_horario`
--

LOCK TABLES `tbl_horario` WRITE;
/*!40000 ALTER TABLE `tbl_horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_malla`
--

DROP TABLE IF EXISTS `tbl_malla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_malla` (
  `pens_id` int(10) NOT NULL AUTO_INCREMENT,
  `uc_id` int(10) NOT NULL,
  `pens_codigo` int(10) NOT NULL,
  `pens_nombre` varchar(30) NOT NULL,
  `pens_anio` smallint(4) NOT NULL,
  `pens_cohorte` varchar(5) NOT NULL,
  `pens_descripcion` varchar(30) NOT NULL,
  `mal_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`pens_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_malla`
--

LOCK TABLES `tbl_malla` WRITE;
/*!40000 ALTER TABLE `tbl_malla` DISABLE KEYS */;
INSERT INTO `tbl_malla` VALUES (1,0,2024001,'PNF Informática V2024',2024,'2024','Plan de estudios PNF Informáti',1);
/*!40000 ALTER TABLE `tbl_malla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_promocion`
--

DROP TABLE IF EXISTS `tbl_promocion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promocion` (
  `his_id` int(10) NOT NULL AUTO_INCREMENT,
  `sec_id_origen` int(10) NOT NULL,
  `sec_id_promocion` int(10) NOT NULL,
  PRIMARY KEY (`his_id`),
  KEY `seccion_origen` (`sec_id_origen`),
  KEY `seccion_promocion` (`sec_id_promocion`),
  CONSTRAINT `seccion_origen` FOREIGN KEY (`sec_id_origen`) REFERENCES `tbl_seccion` (`sec_id`),
  CONSTRAINT `seccion_promocion` FOREIGN KEY (`sec_id_promocion`) REFERENCES `tbl_seccion` (`sec_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_promocion`
--

LOCK TABLES `tbl_promocion` WRITE;
/*!40000 ALTER TABLE `tbl_promocion` DISABLE KEYS */;
INSERT INTO `tbl_promocion` VALUES (1,1,2),(2,2,3);
/*!40000 ALTER TABLE `tbl_promocion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_seccion`
--

DROP TABLE IF EXISTS `tbl_seccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_seccion` (
  `sec_id` int(10) NOT NULL AUTO_INCREMENT,
  `tra_id` int(10) NOT NULL,
  `sec_codigo` varchar(20) NOT NULL,
  `sec_cantidad` int(10) NOT NULL,
  `sec_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`sec_id`),
  KEY `trayecto_seccion` (`tra_id`),
  CONSTRAINT `trayecto_seccion` FOREIGN KEY (`tra_id`) REFERENCES `tbl_trayecto` (`tra_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_seccion`
--

LOCK TABLES `tbl_seccion` WRITE;
/*!40000 ALTER TABLE `tbl_seccion` DISABLE KEYS */;
INSERT INTO `tbl_seccion` VALUES (1,1,'T0-S1-2024',30,1),(2,2,'T1-S1-2024',35,1),(3,3,'T2-S1-2025',25,1);
/*!40000 ALTER TABLE `tbl_seccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_titulo`
--

DROP TABLE IF EXISTS `tbl_titulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_titulo` (
  `tit_id` int(10) NOT NULL AUTO_INCREMENT,
  `tit_prefijo` enum('Ingeniero','Doctorado','Master','') NOT NULL,
  `tit_nombre` varchar(30) NOT NULL,
  `tit_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`tit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_titulo`
--

LOCK TABLES `tbl_titulo` WRITE;
/*!40000 ALTER TABLE `tbl_titulo` DISABLE KEYS */;
INSERT INTO `tbl_titulo` VALUES (1,'Ingeniero','Ing. en Informática',1),(2,'Master','MSc. Gerencia de Proyectos',1);
/*!40000 ALTER TABLE `tbl_titulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_trayecto`
--

DROP TABLE IF EXISTS `tbl_trayecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_trayecto` (
  `tra_id` int(10) NOT NULL AUTO_INCREMENT,
  `tra_numero` enum('0','1','2','3','4') NOT NULL,
  `tra_anio` smallint(4) NOT NULL,
  `tra_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`tra_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_trayecto`
--

LOCK TABLES `tbl_trayecto` WRITE;
/*!40000 ALTER TABLE `tbl_trayecto` DISABLE KEYS */;
INSERT INTO `tbl_trayecto` VALUES (1,'0',2024,1),(2,'1',2024,1),(3,'2',2025,1);
/*!40000 ALTER TABLE `tbl_trayecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_uc`
--

DROP TABLE IF EXISTS `tbl_uc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_uc` (
  `uc_id` int(10) NOT NULL AUTO_INCREMENT,
  `eje_id` int(10) NOT NULL,
  `area_id` int(10) NOT NULL,
  `tra_id` int(10) NOT NULL,
  `uc_codigo` varchar(20) NOT NULL,
  `uc_nombre` varchar(20) NOT NULL,
  `uc_hora_independiente` int(11) NOT NULL,
  `uc_hora_asistida` int(11) NOT NULL,
  `uc_hora_academica` int(11) NOT NULL,
  `uc_creditos` int(11) NOT NULL,
  `uc_periodo` enum('anual','1','2') NOT NULL,
  `uc_electiva` tinyint(1) NOT NULL,
  `uc_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`uc_id`),
  KEY `trayecto_uc` (`tra_id`),
  KEY `eje_uc` (`eje_id`),
  KEY `area_uc` (`area_id`),
  CONSTRAINT `area_uc` FOREIGN KEY (`area_id`) REFERENCES `tbl_area` (`area_id`),
  CONSTRAINT `eje_uc` FOREIGN KEY (`eje_id`) REFERENCES `tbl_eje` (`eje_id`),
  CONSTRAINT `trayecto_uc` FOREIGN KEY (`tra_id`) REFERENCES `tbl_trayecto` (`tra_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_uc`
--

LOCK TABLES `tbl_uc` WRITE;
/*!40000 ALTER TABLE `tbl_uc` DISABLE KEYS */;
INSERT INTO `tbl_uc` VALUES (1,1,1,1,'TIC000','Tecnologías de Inf.',4,2,6,2,'1',0,1),(2,1,1,2,'PRG101','Programación I',6,4,10,4,'anual',0,1),(3,2,2,3,'PSC201','Proyecto Socio II',5,3,8,3,'2',0,1);
/*!40000 ALTER TABLE `tbl_uc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_usuario`
--

DROP TABLE IF EXISTS `tbl_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_usuario` (
  `usu_id` int(10) NOT NULL AUTO_INCREMENT,
  `usu_nombre` varchar(20) NOT NULL,
  `usu_contrasena` varchar(80) NOT NULL,
  `usu_correo` varchar(30) NOT NULL,
  `usu_estado` tinyint(1) NOT NULL,
  `usu_rol` varchar(3) NOT NULL,
  PRIMARY KEY (`usu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_usuario`
--

LOCK TABLES `tbl_usuario` WRITE;
/*!40000 ALTER TABLE `tbl_usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `titulo_docente`
--

DROP TABLE IF EXISTS `titulo_docente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `titulo_docente` (
  `tit_id` int(10) NOT NULL,
  `doc_id` int(10) NOT NULL,
  KEY `docente_titulo` (`doc_id`),
  KEY `titulo_docente` (`tit_id`),
  CONSTRAINT `docente_titulo` FOREIGN KEY (`doc_id`) REFERENCES `tbl_docente` (`doc_id`),
  CONSTRAINT `titulo_docente` FOREIGN KEY (`tit_id`) REFERENCES `tbl_titulo` (`tit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `titulo_docente`
--

LOCK TABLES `titulo_docente` WRITE;
/*!40000 ALTER TABLE `titulo_docente` DISABLE KEYS */;
/*!40000 ALTER TABLE `titulo_docente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uc_docente`
--

DROP TABLE IF EXISTS `uc_docente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uc_docente` (
  `doc_id` int(11) NOT NULL,
  `uc_id` int(11) NOT NULL,
  `uc_doc_estado` tinyint(1) NOT NULL,
  KEY `docente_uc` (`doc_id`),
  KEY `uc_docente` (`uc_id`),
  CONSTRAINT `docente_uc` FOREIGN KEY (`doc_id`) REFERENCES `tbl_docente` (`doc_id`),
  CONSTRAINT `uc_docente` FOREIGN KEY (`uc_id`) REFERENCES `tbl_uc` (`uc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uc_docente`
--

LOCK TABLES `uc_docente` WRITE;
/*!40000 ALTER TABLE `uc_docente` DISABLE KEYS */;
/*!40000 ALTER TABLE `uc_docente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uc_horario`
--

DROP TABLE IF EXISTS `uc_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uc_horario` (
  `uc_id` int(10) NOT NULL,
  `hor_id` int(10) NOT NULL,
  `hor_dia` enum('Lunes','Martes','Miercoles','Jueves','Viernes','Sábado','Domingo') NOT NULL,
  `hor_inicio` varchar(5) NOT NULL,
  `hor_fin` varchar(5) NOT NULL,
  KEY `uc_horario` (`uc_id`),
  KEY `horario_uc` (`hor_id`),
  CONSTRAINT `horario_uc` FOREIGN KEY (`hor_id`) REFERENCES `tbl_horario` (`hor_id`),
  CONSTRAINT `uc_horario` FOREIGN KEY (`uc_id`) REFERENCES `tbl_uc` (`uc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uc_horario`
--

LOCK TABLES `uc_horario` WRITE;
/*!40000 ALTER TABLE `uc_horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `uc_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uc_pensum`
--

DROP TABLE IF EXISTS `uc_pensum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uc_pensum` (
  `pens_id` int(10) NOT NULL,
  `uc_id` int(10) NOT NULL,
  KEY `malla_uc` (`pens_id`),
  KEY `uc_malla` (`uc_id`),
  CONSTRAINT `malla_uc` FOREIGN KEY (`pens_id`) REFERENCES `tbl_malla` (`pens_id`),
  CONSTRAINT `uc_malla` FOREIGN KEY (`uc_id`) REFERENCES `tbl_uc` (`uc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uc_pensum`
--

LOCK TABLES `uc_pensum` WRITE;
/*!40000 ALTER TABLE `uc_pensum` DISABLE KEYS */;
/*!40000 ALTER TABLE `uc_pensum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_orgdocente'
--

--
-- Dumping routines for database 'db_orgdocente'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-29  9:25:41
