-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: db_bitacora
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_bitacora`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_bitacora` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `db_bitacora`;

--
-- Table structure for table `tbl_bitacora`
--

DROP TABLE IF EXISTS `tbl_bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bitacora` (
  `bit_id` int(10) NOT NULL AUTO_INCREMENT,
  `usu_id` int(10) NOT NULL,
  `bit_modulo` varchar(20) NOT NULL,
  `bit_accion` varchar(20) NOT NULL,
  `bit_fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bit_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`bit_id`),
  KEY `bit_usu` (`usu_id`),
  CONSTRAINT `bit_usu` FOREIGN KEY (`usu_id`) REFERENCES `tbl_usuario` (`usu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bitacora`
--

LOCK TABLES `tbl_bitacora` WRITE;
/*!40000 ALTER TABLE `tbl_bitacora` DISABLE KEYS */;
INSERT INTO `tbl_bitacora` VALUES (6,1,'Respaldo','Guardar Respaldo','2025-05-29 13:25:41',1),(7,1,'malla curricular','asignar','2025-05-29 13:40:36',1),(8,1,' malla curricular','asignar certificado','2025-05-29 13:41:00',1),(9,1,'docente','registrar','2025-05-29 13:42:24',1),(10,1,'docente','modificar','2025-05-29 13:48:02',1),(11,1,'docente','modificar','2025-05-29 13:50:34',1),(12,1,'docente','modificar','2025-05-29 13:50:39',1),(13,1,'docente','modificar','2025-05-29 13:50:44',1),(14,1,'docente','modificar','2025-05-29 13:50:51',1),(15,1,'docente','registrar','2025-05-29 13:51:29',1),(16,1,'Unidad Curricular','Asignar','2025-05-29 13:55:35',1),(17,1,'Unidad Curricular','Asignar','2025-05-29 13:55:45',1),(18,1,'Unidad Curricular','Asignar','2025-05-29 13:57:17',1),(19,1,'Unidad Curricular','registrar','2025-05-29 13:58:12',1),(20,1,'Unidad Curricular','Asignar','2025-05-29 13:58:22',1),(21,1,'titulo','registrar','2025-05-29 14:09:51',1),(22,1,'eje','registrar','2025-05-29 14:10:06',1),(23,1,'trayecto','registrar','2025-05-29 14:10:26',1),(24,1,'certificado','registrar','2025-05-29 14:10:43',1),(25,1,'area','registrar','2025-05-29 14:11:11',1),(26,1,'area','registrar','2025-05-29 14:15:47',1),(27,1,'area','eliminar','2025-05-29 14:15:52',1),(28,1,'categoria','registrar','2025-05-29 14:19:32',1),(29,1,'docente','registrar','2025-05-29 14:20:20',1),(30,1,'Unidad Curricular','registrar','2025-05-29 14:21:33',1),(31,1,'Unidad Curricular','Asignar','2025-05-29 14:21:41',1),(32,1,'seccion','registrar','2025-05-29 14:22:23',1),(33,1,'docente','eliminar','2025-05-29 14:29:50',1),(34,1,'docente','registrar','2025-05-29 14:30:19',1),(35,1,'Unidad Curricular','Asignar','2025-05-29 14:30:33',1),(36,1,'area','registrar','2025-05-29 14:56:10',1),(37,1,'categoria','registrar','2025-05-29 14:56:20',1),(38,1,'titulo','registrar','2025-05-29 14:56:36',1),(39,1,'eje','registrar','2025-05-29 14:56:51',1),(40,1,'trayecto','registrar','2025-05-29 14:57:26',1),(41,1,'certificado','registrar','2025-05-29 14:57:45',1),(42,1,'docente','registrar','2025-05-29 14:58:33',1),(43,1,'espacios','registrar','2025-05-29 14:58:44',1),(44,1,'seccion','registrar','2025-05-29 14:58:57',1),(45,1,'Unidad Curricular','registrar','2025-05-29 14:59:26',1),(46,1,'Unidad Curricular','Asignar','2025-05-29 14:59:34',1),(47,1,'malla curricular','registrar','2025-05-29 15:01:26',1),(48,1,'malla curricular','asignar','2025-05-29 15:01:36',1),(49,1,' malla curricular','asignar certificado','2025-05-29 15:01:43',1),(50,1,'archivo','subió un archivo','2025-05-29 15:05:07',1);
/*!40000 ALTER TABLE `tbl_bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_permisos`
--

DROP TABLE IF EXISTS `tbl_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_permisos` (
  `per_id` int(10) NOT NULL AUTO_INCREMENT,
  `usu_id` int(10) NOT NULL,
  `per_permisos` tinyint(2) NOT NULL,
  `per_modulo` varchar(20) NOT NULL,
  `per_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`per_id`),
  KEY `permiso_usuario` (`usu_id`),
  CONSTRAINT `permiso_usuario` FOREIGN KEY (`usu_id`) REFERENCES `tbl_usuario` (`usu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_permisos`
--

LOCK TABLES `tbl_permisos` WRITE;
/*!40000 ALTER TABLE `tbl_permisos` DISABLE KEYS */;
INSERT INTO `tbl_permisos` VALUES (1,1,1,'Area',1),(2,1,2,'Respaldo',1),(3,1,3,'Categorias',1),(4,1,4,'Certificados',1),(5,1,5,'Docentes',1),(6,1,6,'Eje',1),(7,1,7,'Espacios',1),(8,1,8,'Seccion',1),(9,1,9,'Titulo',1),(10,1,10,'Trayecto',1),(11,1,11,'Unidad Curricular',1),(12,1,12,'Horario',1),(13,1,13,'Horario Docente',1),(14,1,14,'Malla Curricular',1),(15,1,15,'Archivos',1),(16,1,16,'Reportes',1),(17,1,17,'Bitacora',1),(18,1,18,'Usuarios',1);
/*!40000 ALTER TABLE `tbl_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_usuario`
--

DROP TABLE IF EXISTS `tbl_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_usuario` (
  `usu_id` int(10) NOT NULL AUTO_INCREMENT,
  `usu_nombre` varchar(30) NOT NULL,
  `usu_correo` varchar(30) NOT NULL,
  `usu_contrasenia` varchar(70) NOT NULL,
  `usu_super` tinyint(1) NOT NULL,
  `usu_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`usu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_usuario`
--

LOCK TABLES `tbl_usuario` WRITE;
/*!40000 ALTER TABLE `tbl_usuario` DISABLE KEYS */;
INSERT INTO `tbl_usuario` VALUES (1,'admin','admin@admin.com','$2y$10$SJsnv1jh/W0QP72822lGz.kcagR4WKfIWSv0vtMw4IWF1NIJbiZD.',1,1);
/*!40000 ALTER TABLE `tbl_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_bitacora'
--

--
-- Dumping routines for database 'db_bitacora'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-29 11:05:33
