-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: db_bitacora
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_bitacora`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_bitacora` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `db_bitacora`;

--
-- Table structure for table `tbl_bitacora`
--

DROP TABLE IF EXISTS `tbl_bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bitacora` (
  `bit_id` int(10) NOT NULL AUTO_INCREMENT,
  `usu_id` int(10) NOT NULL,
  `bit_modulo` varchar(20) NOT NULL,
  `bit_accion` varchar(20) NOT NULL,
  `bit_fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bit_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`bit_id`),
  KEY `bit_usu` (`usu_id`),
  CONSTRAINT `bit_usu` FOREIGN KEY (`usu_id`) REFERENCES `tbl_usuario` (`usu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bitacora`
--

LOCK TABLES `tbl_bitacora` WRITE;
/*!40000 ALTER TABLE `tbl_bitacora` DISABLE KEYS */;
INSERT INTO `tbl_bitacora` VALUES (6,1,'Respaldo','Guardar Respaldo','2025-05-29 13:25:41',1),(7,1,'malla curricular','asignar','2025-05-29 13:40:36',1),(8,1,' malla curricular','asignar certificado','2025-05-29 13:41:00',1),(9,1,'docente','registrar','2025-05-29 13:42:24',1),(10,1,'docente','modificar','2025-05-29 13:48:02',1),(11,1,'docente','modificar','2025-05-29 13:50:34',1),(12,1,'docente','modificar','2025-05-29 13:50:39',1),(13,1,'docente','modificar','2025-05-29 13:50:44',1),(14,1,'docente','modificar','2025-05-29 13:50:51',1),(15,1,'docente','registrar','2025-05-29 13:51:29',1),(16,1,'Unidad Curricular','Asignar','2025-05-29 13:55:35',1),(17,1,'Unidad Curricular','Asignar','2025-05-29 13:55:45',1),(18,1,'Unidad Curricular','Asignar','2025-05-29 13:57:17',1),(19,1,'Unidad Curricular','registrar','2025-05-29 13:58:12',1),(20,1,'Unidad Curricular','Asignar','2025-05-29 13:58:22',1),(21,1,'titulo','registrar','2025-05-29 14:09:51',1),(22,1,'eje','registrar','2025-05-29 14:10:06',1),(23,1,'trayecto','registrar','2025-05-29 14:10:26',1),(24,1,'certificado','registrar','2025-05-29 14:10:43',1),(25,1,'area','registrar','2025-05-29 14:11:11',1),(26,1,'area','registrar','2025-05-29 14:15:47',1),(27,1,'area','eliminar','2025-05-29 14:15:52',1),(28,1,'categoria','registrar','2025-05-29 14:19:32',1),(29,1,'docente','registrar','2025-05-29 14:20:20',1),(30,1,'Unidad Curricular','registrar','2025-05-29 14:21:33',1),(31,1,'Unidad Curricular','Asignar','2025-05-29 14:21:41',1),(32,1,'seccion','registrar','2025-05-29 14:22:23',1),(33,1,'docente','eliminar','2025-05-29 14:29:50',1),(34,1,'docente','registrar','2025-05-29 14:30:19',1),(35,1,'Unidad Curricular','Asignar','2025-05-29 14:30:33',1),(36,1,'area','registrar','2025-05-29 14:56:10',1),(37,1,'categoria','registrar','2025-05-29 14:56:20',1),(38,1,'titulo','registrar','2025-05-29 14:56:36',1),(39,1,'eje','registrar','2025-05-29 14:56:51',1),(40,1,'trayecto','registrar','2025-05-29 14:57:26',1),(41,1,'certificado','registrar','2025-05-29 14:57:45',1),(42,1,'docente','registrar','2025-05-29 14:58:33',1),(43,1,'espacios','registrar','2025-05-29 14:58:44',1),(44,1,'seccion','registrar','2025-05-29 14:58:57',1),(45,1,'Unidad Curricular','registrar','2025-05-29 14:59:26',1),(46,1,'Unidad Curricular','Asignar','2025-05-29 14:59:34',1),(47,1,'malla curricular','registrar','2025-05-29 15:01:26',1),(48,1,'malla curricular','asignar','2025-05-29 15:01:36',1),(49,1,' malla curricular','asignar certificado','2025-05-29 15:01:43',1),(50,1,'archivo','subió un archivo','2025-05-29 15:05:07',1),(51,1,'Respaldo','Guardar Respaldo','2025-05-29 15:05:33',1),(52,1,'usuario','registrar','2025-05-29 15:06:53',1),(53,1,'docente','modificar','2025-05-29 15:38:48',1),(54,1,'espacios','modificar','2025-05-29 15:39:00',1),(55,1,'espacios','modificar','2025-05-29 15:39:07',1),(56,1,'espacios','modificar','2025-05-29 15:39:36',1),(57,1,'Unidad Curricular','modificar','2025-05-29 15:42:13',1),(58,1,'usuario','registrar','2025-05-29 17:08:29',1),(59,1,'malla curricular','registrar','2025-06-06 04:22:37',1),(60,1,'turno','registrar','2025-06-18 02:44:25',1),(61,1,'turno','modificar','2025-06-18 02:44:39',1),(62,1,'turno','modificar','2025-06-18 02:45:18',1),(63,1,'turno','modificar','2025-06-18 02:48:47',1),(64,1,'turno','registrar','2025-06-18 02:49:02',1),(65,1,'turno','eliminar','2025-06-18 02:49:28',1),(66,1,'titulo','registrar','2025-06-18 02:50:36',1),(67,1,'malla curricular','registrar','2025-06-19 02:17:48',1),(68,1,'malla curricular','registrar','2025-06-19 02:18:53',1),(69,1,'anio','registrar','2025-06-19 03:24:58',1),(70,1,'cohorte','registrar','2025-06-19 03:39:25',1),(71,1,'cohorte','registrar','2025-06-19 06:07:12',1),(72,1,'anio','registrar','2025-06-19 06:07:30',1),(73,1,'anio','activar','2025-06-19 06:07:35',1),(74,1,'malla curricular','registrar','2025-06-19 06:29:52',1),(75,1,'malla curricular','registrar','2025-06-19 06:30:07',1),(76,1,'malla curricular','registrar','2025-06-19 06:30:12',1),(77,1,'malla curricular','registrar','2025-06-19 06:30:15',1),(78,1,'malla curricular','registrar','2025-06-19 06:30:16',1),(79,1,'malla curricular','registrar','2025-06-19 06:30:19',1),(80,1,'malla curricular','registrar','2025-06-19 06:30:19',1),(81,1,'malla curricular','registrar','2025-06-19 06:30:19',1),(82,1,'malla curricular','registrar','2025-06-19 06:30:19',1),(83,1,'malla curricular','registrar','2025-06-19 06:30:20',1),(84,1,'turno','registrar','2025-06-19 19:39:09',1),(85,1,'eje','registrar','2025-06-19 19:46:50',1),(86,1,'anio','registrar','2025-06-19 19:48:33',1),(87,1,'anio','activar','2025-06-19 19:48:35',1),(88,1,'cohorte','registrar','2025-06-19 19:51:16',1),(89,1,'malla curricular','registrar','2025-06-19 19:52:43',1),(90,1,'malla curricular','registrar','2025-06-19 19:55:37',1),(91,1,'malla curricular','registrar','2025-06-19 20:15:05',1),(92,1,'malla curricular','registrar','2025-06-19 20:27:30',1),(93,1,'titulo','registrar','2025-06-19 20:48:17',1),(94,1,'malla curricular','registrar','2025-06-19 20:59:31',1),(95,1,'malla curricular','registrar','2025-06-19 20:59:37',1),(96,1,'malla curricular','modificar','2025-06-19 20:59:54',1),(97,1,'malla curricular','modificar','2025-06-19 20:59:56',1),(98,1,'malla curricular','modificar','2025-06-19 21:00:08',1),(99,1,'malla curricular','modificar','2025-06-19 21:00:13',1),(100,1,'eje','modificar','2025-06-19 21:01:29',1),(101,1,'titulo','registrar','2025-06-19 21:01:59',1),(102,1,'titulo','modificar','2025-06-19 21:02:18',1),(103,1,'titulo','modificar','2025-06-19 21:02:34',1),(104,1,'titulo','modificar','2025-06-19 21:02:39',1),(105,1,'malla curricular','modificar','2025-06-19 21:02:57',1),(106,1,'malla curricular','modificar','2025-06-19 21:02:58',1),(107,1,'malla curricular','modificar','2025-06-19 21:03:00',1),(108,1,'malla curricular','modificar','2025-06-19 21:03:44',1),(109,1,'malla curricular','modificar','2025-06-19 21:03:47',1),(110,1,'malla curricular','modificar','2025-06-19 21:03:59',1),(111,1,'malla curricular','modificar','2025-06-19 21:05:53',1),(112,1,'malla curricular','modificar','2025-06-19 21:05:54',1),(113,1,'malla curricular','modificar','2025-06-19 21:05:55',1),(114,1,'malla curricular','modificar','2025-06-19 21:05:56',1),(115,1,'malla curricular','modificar','2025-06-19 21:05:59',1),(116,1,'malla curricular','modificar','2025-06-19 21:06:00',1),(117,1,'malla curricular','modificar','2025-06-19 21:06:01',1),(118,1,'malla curricular','modificar','2025-06-19 21:06:01',1),(119,1,'malla curricular','eliminar','2025-06-19 21:07:14',1),(120,1,'malla curricular','modificar','2025-06-19 21:07:25',1),(121,1,'malla curricular','modificar','2025-06-19 21:07:26',1),(122,1,'titulo','modificar','2025-06-19 21:09:06',1),(123,1,'titulo','modificar','2025-06-19 21:09:31',1),(124,1,'titulo','modificar','2025-06-19 21:09:38',1),(125,1,'titulo','modificar','2025-06-19 21:09:42',1),(126,1,'titulo','modificar','2025-06-19 21:09:45',1),(127,1,'malla curricular','registrar','2025-06-19 21:22:23',1),(128,1,'malla curricular','modificar','2025-06-19 21:22:41',1),(129,1,'malla curricular','modificar','2025-06-19 21:31:28',1),(130,1,'malla curricular','registrar','2025-06-20 01:04:43',1),(131,1,'certificado','registrar','2025-06-20 01:22:02',1),(132,1,' malla curricular','asignar certificado','2025-06-20 01:29:53',1),(133,1,' malla curricular','asignar certificado','2025-06-20 01:30:00',1),(134,1,' malla curricular','asignar certificado','2025-06-20 01:31:09',1),(135,1,'malla curricular','asignar','2025-06-20 01:44:42',1),(136,1,'malla curricular','asignar','2025-06-20 01:48:07',1),(137,1,'malla curricular','asignar','2025-06-20 01:48:20',1),(138,1,'malla curricular','asignar','2025-06-20 01:49:06',1),(139,1,'malla curricular','asignar','2025-06-20 01:49:10',1),(140,1,'malla curricular','asignar','2025-06-20 01:49:26',1),(141,1,'malla curricular','asignar','2025-06-20 01:50:00',1),(142,1,'malla curricular','asignar','2025-06-20 01:50:02',1),(143,1,'malla curricular','asignar','2025-06-20 01:50:04',1),(144,1,'malla curricular','asignar','2025-06-20 01:51:48',1),(145,1,'malla curricular','asignar','2025-06-20 01:54:31',1),(146,1,'certificado','registrar','2025-06-20 02:00:57',1),(147,1,'certificado','registrar','2025-06-20 02:10:11',1),(148,1,'certificado','registrar','2025-06-20 02:10:16',1),(149,1,'certificado','modificar','2025-06-20 02:10:23',1),(150,1,'certificado','modificar','2025-06-20 02:10:29',1),(151,1,'certificado','modificar','2025-06-20 02:10:31',1),(152,1,'certificado','modificar','2025-06-20 02:12:05',1),(153,1,'certificado','modificar','2025-06-20 03:45:36',1),(154,1,'certificado','modificar','2025-06-20 03:45:37',1),(155,1,'certificado','modificar','2025-06-20 03:45:39',1),(156,1,'certificado','modificar','2025-06-20 03:49:14',1),(157,1,'certificado','registrar','2025-06-20 03:49:46',1),(158,1,'malla curricular','registrar','2025-06-20 03:58:11',1),(159,1,'malla curricular','registrar','2025-06-20 03:58:11',1),(160,1,'malla curricular','registrar','2025-06-20 03:58:25',1),(161,1,'categoria','registrar','2025-06-20 03:59:01',1),(162,1,'docente','registrar','2025-06-20 04:02:16',1),(163,1,'docente','registrar','2025-06-20 04:02:37',1),(164,1,'espacios','registrar','2025-06-20 04:02:46',1),(165,1,'trayecto','registrar','2025-06-20 04:03:03',1),(166,1,'trayecto','registrar','2025-06-20 04:03:12',1),(167,1,'certificado','registrar','2025-06-20 04:03:33',1),(168,1,'area','registrar','2025-06-20 04:03:45',1),(169,1,'area','registrar','2025-06-20 04:06:00',1),(170,1,'categoria','registrar','2025-06-20 04:06:11',1),(171,1,'eje','registrar','2025-06-20 04:06:21',1),(172,1,'Respaldo','Guardar Respaldo','2025-06-20 04:08:35',1);
/*!40000 ALTER TABLE `tbl_bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_permisos`
--

DROP TABLE IF EXISTS `tbl_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_permisos` (
  `per_id` int(10) NOT NULL AUTO_INCREMENT,
  `usu_id` int(10) NOT NULL,
  `per_permisos` tinyint(2) NOT NULL,
  `per_modulo` varchar(20) NOT NULL,
  `per_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`per_id`),
  KEY `permiso_usuario` (`usu_id`),
  CONSTRAINT `permiso_usuario` FOREIGN KEY (`usu_id`) REFERENCES `tbl_usuario` (`usu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_permisos`
--

LOCK TABLES `tbl_permisos` WRITE;
/*!40000 ALTER TABLE `tbl_permisos` DISABLE KEYS */;
INSERT INTO `tbl_permisos` VALUES (1,1,1,'Area',1),(2,1,2,'Respaldo',1),(3,1,3,'Categorias',1),(4,1,4,'Certificados',1),(5,1,5,'Docentes',1),(6,1,6,'Eje',1),(7,1,7,'Espacios',1),(8,1,8,'Seccion',1),(9,1,9,'Titulo',1),(10,1,10,'Trayecto',1),(11,1,11,'Unidad Curricular',1),(12,1,12,'Horario',1),(13,1,13,'Horario Docente',1),(14,1,14,'Malla Curricular',1),(15,1,15,'Archivos',1),(16,1,16,'Reportes',1),(17,1,17,'Bitacora',1),(18,1,18,'Usuarios',1),(19,2,4,'Certificados',1);
/*!40000 ALTER TABLE `tbl_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_usuario`
--

DROP TABLE IF EXISTS `tbl_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_usuario` (
  `usu_id` int(10) NOT NULL AUTO_INCREMENT,
  `usu_nombre` varchar(30) NOT NULL,
  `usu_correo` varchar(30) NOT NULL,
  `usu_contrasenia` varchar(70) NOT NULL,
  `usu_super` tinyint(1) NOT NULL,
  `usu_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`usu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_usuario`
--

LOCK TABLES `tbl_usuario` WRITE;
/*!40000 ALTER TABLE `tbl_usuario` DISABLE KEYS */;
INSERT INTO `tbl_usuario` VALUES (1,'admin','admin@admin.com','$2y$10$SJsnv1jh/W0QP72822lGz.kcagR4WKfIWSv0vtMw4IWF1NIJbiZD.',1,1),(2,'usua','usuarii@gmail.com','$2y$10$1n1K.QhqvWUkachdMjCZx.AxBOgV0wEnmYAK6wsJKBr9zBY0Abn.u',0,1),(3,'qeeee','hola@gmail.com','$2y$10$yfiaBB1KLmsMGQiwvQGMNuhtfy.djLSyVz4IIfEenjZWrKAcKPmT.',0,1);
/*!40000 ALTER TABLE `tbl_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_bitacora'
--

--
-- Dumping routines for database 'db_bitacora'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-20  0:08:59
