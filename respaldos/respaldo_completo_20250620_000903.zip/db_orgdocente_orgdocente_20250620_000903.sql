-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: db_orgdocente
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_orgdocente`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_orgdocente` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `db_orgdocente`;

--
-- Table structure for table `coordinacion_docente`
--

DROP TABLE IF EXISTS `coordinacion_docente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coordinacion_docente` (
  `cor_id` int(10) NOT NULL,
  `doc_id` int(10) NOT NULL,
  `cor_doc_estado` tinyint(1) NOT NULL,
  KEY `cor_id` (`cor_id`),
  KEY `doc_id` (`doc_id`),
  CONSTRAINT `coordinacion_docente_ibfk_1` FOREIGN KEY (`cor_id`) REFERENCES `tbl_coordinacion` (`cor_id`),
  CONSTRAINT `coordinacion_docente_ibfk_2` FOREIGN KEY (`doc_id`) REFERENCES `tbl_docente` (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coordinacion_docente`
--

LOCK TABLES `coordinacion_docente` WRITE;
/*!40000 ALTER TABLE `coordinacion_docente` DISABLE KEYS */;
/*!40000 ALTER TABLE `coordinacion_docente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crear_horariodocente`
--

DROP TABLE IF EXISTS `crear_horariodocente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crear_horariodocente` (
  `hor_id` int(10) NOT NULL,
  `hdo_id` int(10) NOT NULL,
  PRIMARY KEY (`hor_id`,`hdo_id`),
  KEY `hdo_id` (`hdo_id`),
  CONSTRAINT `crear_horariodocente_ibfk_1` FOREIGN KEY (`hor_id`) REFERENCES `tbl_horario` (`hor_id`),
  CONSTRAINT `crear_horariodocente_ibfk_2` FOREIGN KEY (`hdo_id`) REFERENCES `tbl_horariodocente` (`hdo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crear_horariodocente`
--

LOCK TABLES `crear_horariodocente` WRITE;
/*!40000 ALTER TABLE `crear_horariodocente` DISABLE KEYS */;
/*!40000 ALTER TABLE `crear_horariodocente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docente_horario`
--

DROP TABLE IF EXISTS `docente_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docente_horario` (
  `doc_id` int(10) NOT NULL,
  `hor_id` int(10) NOT NULL,
  PRIMARY KEY (`doc_id`,`hor_id`),
  KEY `hor_id` (`hor_id`),
  CONSTRAINT `docente_horario_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `tbl_docente` (`doc_id`),
  CONSTRAINT `docente_horario_ibfk_2` FOREIGN KEY (`hor_id`) REFERENCES `tbl_horario` (`hor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docente_horario`
--

LOCK TABLES `docente_horario` WRITE;
/*!40000 ALTER TABLE `docente_horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `docente_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pensum_certificado`
--

DROP TABLE IF EXISTS `pensum_certificado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pensum_certificado` (
  `mal_id` int(10) NOT NULL,
  `cert_id` int(10) NOT NULL,
  PRIMARY KEY (`mal_id`,`cert_id`),
  KEY `cert_id` (`cert_id`),
  CONSTRAINT `pensum_certificado_ibfk_1` FOREIGN KEY (`mal_id`) REFERENCES `tbl_malla` (`mal_id`),
  CONSTRAINT `pensum_certificado_ibfk_2` FOREIGN KEY (`cert_id`) REFERENCES `tbl_certificacion` (`cert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pensum_certificado`
--

LOCK TABLES `pensum_certificado` WRITE;
/*!40000 ALTER TABLE `pensum_certificado` DISABLE KEYS */;
INSERT INTO `pensum_certificado` VALUES (1,1);
/*!40000 ALTER TABLE `pensum_certificado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seccion_horario`
--

DROP TABLE IF EXISTS `seccion_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seccion_horario` (
  `sec_id` int(10) NOT NULL,
  `hor_id` int(10) NOT NULL,
  PRIMARY KEY (`sec_id`,`hor_id`),
  KEY `hor_id` (`hor_id`),
  CONSTRAINT `seccion_horario_ibfk_1` FOREIGN KEY (`sec_id`) REFERENCES `tbl_seccion` (`sec_id`),
  CONSTRAINT `seccion_horario_ibfk_2` FOREIGN KEY (`hor_id`) REFERENCES `tbl_horario` (`hor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seccion_horario`
--

LOCK TABLES `seccion_horario` WRITE;
/*!40000 ALTER TABLE `seccion_horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `seccion_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_anio`
--

DROP TABLE IF EXISTS `tbl_anio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_anio` (
  `ani_id` int(10) NOT NULL AUTO_INCREMENT,
  `ani_anio` year(4) NOT NULL,
  `ani_activo` date NOT NULL,
  `ani_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`ani_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_anio`
--

LOCK TABLES `tbl_anio` WRITE;
/*!40000 ALTER TABLE `tbl_anio` DISABLE KEYS */;
INSERT INTO `tbl_anio` VALUES (1,2025,'0000-00-00',1);
/*!40000 ALTER TABLE `tbl_anio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_area`
--

DROP TABLE IF EXISTS `tbl_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_area` (
  `area_id` int(10) NOT NULL AUTO_INCREMENT,
  `area_nombre` varchar(30) NOT NULL,
  `area_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_area`
--

LOCK TABLES `tbl_area` WRITE;
/*!40000 ALTER TABLE `tbl_area` DISABLE KEYS */;
INSERT INTO `tbl_area` VALUES (1,'fdgfd',1),(2,'aaaa',1),(3,'asddd',1);
/*!40000 ALTER TABLE `tbl_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_categoria`
--

DROP TABLE IF EXISTS `tbl_categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_categoria` (
  `cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_nombre` varchar(30) NOT NULL,
  `cat_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_categoria`
--

LOCK TABLES `tbl_categoria` WRITE;
/*!40000 ALTER TABLE `tbl_categoria` DISABLE KEYS */;
INSERT INTO `tbl_categoria` VALUES (1,'aaaaaaaaaaaa',1),(2,'asasaa',1);
/*!40000 ALTER TABLE `tbl_categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_certificacion`
--

DROP TABLE IF EXISTS `tbl_certificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_certificacion` (
  `cert_id` int(10) NOT NULL AUTO_INCREMENT,
  `tra_id` int(10) NOT NULL,
  `cert_nombre` varchar(20) NOT NULL,
  `cert_tipo` varchar(30) NOT NULL,
  `cert_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`cert_id`),
  KEY `tra_id` (`tra_id`),
  CONSTRAINT `tbl_certificacion_ibfk_1` FOREIGN KEY (`tra_id`) REFERENCES `tbl_trayecto` (`tra_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_certificacion`
--

LOCK TABLES `tbl_certificacion` WRITE;
/*!40000 ALTER TABLE `tbl_certificacion` DISABLE KEYS */;
INSERT INTO `tbl_certificacion` VALUES (1,1,'asdadsd','sdssd',1),(2,1,'12312asa','jjjjjjj',1),(3,1,'12312h','',1),(4,1,'jkdnksknjdja','hbsdfhbshd',1),(5,1,'sdxsca','zxcxz',1);
/*!40000 ALTER TABLE `tbl_certificacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_cohorte`
--

DROP TABLE IF EXISTS `tbl_cohorte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cohorte` (
  `coh_id` int(10) NOT NULL AUTO_INCREMENT,
  `coh_numero` int(10) NOT NULL,
  `coh_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`coh_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cohorte`
--

LOCK TABLES `tbl_cohorte` WRITE;
/*!40000 ALTER TABLE `tbl_cohorte` DISABLE KEYS */;
INSERT INTO `tbl_cohorte` VALUES (1,131,1);
/*!40000 ALTER TABLE `tbl_cohorte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_convenio`
--

DROP TABLE IF EXISTS `tbl_convenio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_convenio` (
  `con_id` int(10) NOT NULL AUTO_INCREMENT,
  `tra_id` int(10) NOT NULL,
  `con_nombre` varchar(30) NOT NULL,
  `con_inicio` date NOT NULL,
  `con_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`con_id`),
  KEY `tra_id` (`tra_id`),
  CONSTRAINT `tbl_convenio_ibfk_1` FOREIGN KEY (`tra_id`) REFERENCES `tbl_trayecto` (`tra_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_convenio`
--

LOCK TABLES `tbl_convenio` WRITE;
/*!40000 ALTER TABLE `tbl_convenio` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_convenio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_coordinacion`
--

DROP TABLE IF EXISTS `tbl_coordinacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_coordinacion` (
  `cor_id` int(10) NOT NULL AUTO_INCREMENT,
  `cor_nombre` varchar(30) NOT NULL,
  `cor_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`cor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_coordinacion`
--

LOCK TABLES `tbl_coordinacion` WRITE;
/*!40000 ALTER TABLE `tbl_coordinacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_coordinacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_docente`
--

DROP TABLE IF EXISTS `tbl_docente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_docente` (
  `doc_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) NOT NULL,
  `doc_prefijo` char(1) NOT NULL,
  `doc_cedula` int(10) NOT NULL,
  `doc_nombre` varchar(30) NOT NULL,
  `doc_apellido` varchar(30) NOT NULL,
  `doc_correo` varchar(30) NOT NULL,
  `doc_dedicacion` enum('exclusiva','ordinaria','contratado') NOT NULL,
  `doc_condicion` enum('medio','completo','parcial') NOT NULL,
  `doc_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`doc_id`),
  KEY `cat_id` (`cat_id`),
  CONSTRAINT `tbl_docente_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `tbl_categoria` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_docente`
--

LOCK TABLES `tbl_docente` WRITE;
/*!40000 ALTER TABLE `tbl_docente` DISABLE KEYS */;
INSERT INTO `tbl_docente` VALUES (1,1,'V',12123123,'sadasdas','asdasdas','rijalscarra55@gmail.com','exclusiva','',1),(2,1,'V',64564545,'illulh','gjhfghj','rijalscarra55@gmail.com','exclusiva','',1);
/*!40000 ALTER TABLE `tbl_docente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_eje`
--

DROP TABLE IF EXISTS `tbl_eje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_eje` (
  `eje_id` int(10) NOT NULL AUTO_INCREMENT,
  `eje_nombre` varchar(30) NOT NULL,
  `eje_descripcion` varchar(50) NOT NULL,
  `eje_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`eje_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_eje`
--

LOCK TABLES `tbl_eje` WRITE;
/*!40000 ALTER TABLE `tbl_eje` DISABLE KEYS */;
INSERT INTO `tbl_eje` VALUES (1,'dcfkll','',1),(2,'gfgdffsd','',1);
/*!40000 ALTER TABLE `tbl_eje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_espacio`
--

DROP TABLE IF EXISTS `tbl_espacio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_espacio` (
  `esp_id` int(10) NOT NULL AUTO_INCREMENT,
  `esp_codigo` varchar(20) NOT NULL,
  `esp_tipo` enum('aula','laboratorio') NOT NULL,
  `esp_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`esp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_espacio`
--

LOCK TABLES `tbl_espacio` WRITE;
/*!40000 ALTER TABLE `tbl_espacio` DISABLE KEYS */;
INSERT INTO `tbl_espacio` VALUES (1,'sdcsd','aula',1);
/*!40000 ALTER TABLE `tbl_espacio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_fase`
--

DROP TABLE IF EXISTS `tbl_fase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_fase` (
  `fase_id` int(10) NOT NULL AUTO_INCREMENT,
  `tra_id` int(10) NOT NULL,
  `fase_numero` enum('1','2') NOT NULL,
  `fase_apertura` date NOT NULL,
  `fase_cierre` date NOT NULL,
  `fase_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`fase_id`),
  KEY `tra_id` (`tra_id`),
  CONSTRAINT `tbl_fase_ibfk_1` FOREIGN KEY (`tra_id`) REFERENCES `tbl_trayecto` (`tra_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_fase`
--

LOCK TABLES `tbl_fase` WRITE;
/*!40000 ALTER TABLE `tbl_fase` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_fase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_horario`
--

DROP TABLE IF EXISTS `tbl_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_horario` (
  `hor_id` int(10) NOT NULL AUTO_INCREMENT,
  `fase_id` int(10) NOT NULL,
  `esp_id` int(10) NOT NULL,
  `tur_id` int(10) NOT NULL,
  `hor_modalidad` enum('presencial','semipresencial') NOT NULL,
  `hor_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`hor_id`),
  KEY `fase_id` (`fase_id`),
  KEY `tur_id` (`tur_id`),
  KEY `esp_id` (`esp_id`),
  CONSTRAINT `tbl_horario_ibfk_1` FOREIGN KEY (`fase_id`) REFERENCES `tbl_fase` (`fase_id`),
  CONSTRAINT `tbl_horario_ibfk_2` FOREIGN KEY (`tur_id`) REFERENCES `tbl_turno` (`tur_id`),
  CONSTRAINT `tbl_horario_ibfk_3` FOREIGN KEY (`esp_id`) REFERENCES `tbl_espacio` (`esp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_horario`
--

LOCK TABLES `tbl_horario` WRITE;
/*!40000 ALTER TABLE `tbl_horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_horariodocente`
--

DROP TABLE IF EXISTS `tbl_horariodocente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_horariodocente` (
  `hdo_id` int(10) NOT NULL AUTO_INCREMENT,
  `doc_id` int(10) NOT NULL,
  `hdo_lapso` varchar(10) NOT NULL,
  `hdo_tipoactividad` varchar(30) NOT NULL,
  `hdo_descripcion` varchar(20) NOT NULL,
  `hdo_dependencia` varchar(30) NOT NULL,
  `hdo_observacion` varchar(30) NOT NULL,
  `hdo_horas` varchar(30) NOT NULL,
  `hdo_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`hdo_id`),
  KEY `doc_id` (`doc_id`),
  CONSTRAINT `tbl_horariodocente_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `tbl_docente` (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_horariodocente`
--

LOCK TABLES `tbl_horariodocente` WRITE;
/*!40000 ALTER TABLE `tbl_horariodocente` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_horariodocente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_malla`
--

DROP TABLE IF EXISTS `tbl_malla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_malla` (
  `mal_id` int(10) NOT NULL AUTO_INCREMENT,
  `coh_id` int(10) NOT NULL,
  `ani_id` int(10) NOT NULL,
  `mal_codigo` varchar(10) NOT NULL,
  `mal_nombre` varchar(30) NOT NULL,
  `mal_descripcion` varchar(30) NOT NULL,
  `mal_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`mal_id`),
  KEY `coh_id` (`coh_id`),
  KEY `ani_id` (`ani_id`),
  CONSTRAINT `tbl_malla_ibfk_1` FOREIGN KEY (`coh_id`) REFERENCES `tbl_cohorte` (`coh_id`),
  CONSTRAINT `tbl_malla_ibfk_2` FOREIGN KEY (`ani_id`) REFERENCES `tbl_anio` (`ani_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_malla`
--

LOCK TABLES `tbl_malla` WRITE;
/*!40000 ALTER TABLE `tbl_malla` DISABLE KEYS */;
INSERT INTO `tbl_malla` VALUES (1,1,1,'12321','1156156','olaaaa',1),(2,1,1,'12343','malla 2203','sjdajsdja',1),(3,1,1,'11244','malla 22','sadasda',0),(4,1,1,'23423','sgfdgdf','dfgdfgsdf',1),(5,1,1,'asdasd','asdasd','asdasdas',1),(6,1,1,'asssss','asddddddd','sadassad',1);
/*!40000 ALTER TABLE `tbl_malla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_prosecucion`
--

DROP TABLE IF EXISTS `tbl_prosecucion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_prosecucion` (
  `pro_id` int(10) NOT NULL AUTO_INCREMENT,
  `sec_id_origen` int(10) NOT NULL,
  `sec_id_promocion` int(10) NOT NULL,
  PRIMARY KEY (`pro_id`),
  KEY `sec_id_origen` (`sec_id_origen`),
  KEY `sec_id_promocion` (`sec_id_promocion`),
  CONSTRAINT `tbl_prosecucion_ibfk_1` FOREIGN KEY (`sec_id_origen`) REFERENCES `tbl_seccion` (`sec_id`),
  CONSTRAINT `tbl_prosecucion_ibfk_2` FOREIGN KEY (`sec_id_promocion`) REFERENCES `tbl_seccion` (`sec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_prosecucion`
--

LOCK TABLES `tbl_prosecucion` WRITE;
/*!40000 ALTER TABLE `tbl_prosecucion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_prosecucion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_seccion`
--

DROP TABLE IF EXISTS `tbl_seccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_seccion` (
  `sec_id` int(10) NOT NULL AUTO_INCREMENT,
  `tra_id` int(10) NOT NULL,
  `coh_id` int(10) NOT NULL,
  `sec_nombre` varchar(5) NOT NULL,
  `sec_codigo` varchar(10) NOT NULL,
  `sec_cantidad` int(10) NOT NULL,
  `sec_grupo` int(4) NOT NULL,
  `sec_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`sec_id`),
  KEY `tra_id` (`tra_id`),
  KEY `coh_id` (`coh_id`),
  CONSTRAINT `tbl_seccion_ibfk_1` FOREIGN KEY (`tra_id`) REFERENCES `tbl_trayecto` (`tra_id`),
  CONSTRAINT `tbl_seccion_ibfk_2` FOREIGN KEY (`coh_id`) REFERENCES `tbl_cohorte` (`coh_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_seccion`
--

LOCK TABLES `tbl_seccion` WRITE;
/*!40000 ALTER TABLE `tbl_seccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_seccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_titulo`
--

DROP TABLE IF EXISTS `tbl_titulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_titulo` (
  `tit_id` int(10) NOT NULL AUTO_INCREMENT,
  `tit_prefijo` varchar(20) NOT NULL,
  `tit_nombre` varchar(20) NOT NULL,
  `tit_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`tit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_titulo`
--

LOCK TABLES `tbl_titulo` WRITE;
/*!40000 ALTER TABLE `tbl_titulo` DISABLE KEYS */;
INSERT INTO `tbl_titulo` VALUES (1,'Ingeniero','jjjjj',1),(2,'Ingeniero','jjjjjs',1);
/*!40000 ALTER TABLE `tbl_titulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_trayecto`
--

DROP TABLE IF EXISTS `tbl_trayecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_trayecto` (
  `tra_id` int(10) NOT NULL AUTO_INCREMENT,
  `tra_numero` enum('inicial','1','2','3','4') NOT NULL,
  `tra_tipo` enum('regular','intensivo') NOT NULL,
  `tra_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`tra_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_trayecto`
--

LOCK TABLES `tbl_trayecto` WRITE;
/*!40000 ALTER TABLE `tbl_trayecto` DISABLE KEYS */;
INSERT INTO `tbl_trayecto` VALUES (1,'1','intensivo',1),(2,'inicial','',1);
/*!40000 ALTER TABLE `tbl_trayecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_turno`
--

DROP TABLE IF EXISTS `tbl_turno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_turno` (
  `tur_id` int(10) NOT NULL AUTO_INCREMENT,
  `tur_horainicio` time NOT NULL,
  `tur_horafin` time NOT NULL,
  `tur_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`tur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_turno`
--

LOCK TABLES `tbl_turno` WRITE;
/*!40000 ALTER TABLE `tbl_turno` DISABLE KEYS */;
INSERT INTO `tbl_turno` VALUES (1,'16:38:00','20:46:00',1);
/*!40000 ALTER TABLE `tbl_turno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_uc`
--

DROP TABLE IF EXISTS `tbl_uc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_uc` (
  `uc_id` int(10) NOT NULL AUTO_INCREMENT,
  `eje_id` int(10) NOT NULL,
  `tra_id` int(10) NOT NULL,
  `area_id` int(10) NOT NULL,
  `uc_codigo` varchar(30) NOT NULL,
  `uc_nombre` varchar(30) NOT NULL,
  `uc_hora_independiente` int(3) NOT NULL,
  `uc_hora_asistida` int(3) NOT NULL,
  `uc_hora_academica` int(3) NOT NULL,
  `uc_creditos` int(2) NOT NULL,
  `uc_periodo` enum('anual','0','1','2') NOT NULL,
  `uc_electiva` tinyint(1) NOT NULL,
  `uc_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`uc_id`),
  KEY `eje_id` (`eje_id`),
  KEY `tra_id` (`tra_id`),
  KEY `area_id` (`area_id`),
  CONSTRAINT `tbl_uc_ibfk_1` FOREIGN KEY (`eje_id`) REFERENCES `tbl_eje` (`eje_id`),
  CONSTRAINT `tbl_uc_ibfk_2` FOREIGN KEY (`tra_id`) REFERENCES `tbl_trayecto` (`tra_id`),
  CONSTRAINT `tbl_uc_ibfk_3` FOREIGN KEY (`area_id`) REFERENCES `tbl_area` (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_uc`
--

LOCK TABLES `tbl_uc` WRITE;
/*!40000 ALTER TABLE `tbl_uc` DISABLE KEYS */;
INSERT INTO `tbl_uc` VALUES (2,1,1,1,'asdas','[vasdalue-5]',0,0,0,0,'',0,1);
/*!40000 ALTER TABLE `tbl_uc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `titulo_docente`
--

DROP TABLE IF EXISTS `titulo_docente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `titulo_docente` (
  `doc_id` int(10) NOT NULL,
  `tit_id` int(10) NOT NULL,
  PRIMARY KEY (`doc_id`,`tit_id`),
  KEY `tit_id` (`tit_id`),
  CONSTRAINT `titulo_docente_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `tbl_docente` (`doc_id`),
  CONSTRAINT `titulo_docente_ibfk_2` FOREIGN KEY (`tit_id`) REFERENCES `tbl_titulo` (`tit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `titulo_docente`
--

LOCK TABLES `titulo_docente` WRITE;
/*!40000 ALTER TABLE `titulo_docente` DISABLE KEYS */;
INSERT INTO `titulo_docente` VALUES (1,1),(2,1);
/*!40000 ALTER TABLE `titulo_docente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uc_docente`
--

DROP TABLE IF EXISTS `uc_docente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uc_docente` (
  `doc_id` int(10) NOT NULL,
  `uc_id` int(10) NOT NULL,
  `uc_doc_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`doc_id`,`uc_id`),
  KEY `uc_id` (`uc_id`),
  CONSTRAINT `uc_docente_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `tbl_docente` (`doc_id`),
  CONSTRAINT `uc_docente_ibfk_2` FOREIGN KEY (`uc_id`) REFERENCES `tbl_uc` (`uc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uc_docente`
--

LOCK TABLES `uc_docente` WRITE;
/*!40000 ALTER TABLE `uc_docente` DISABLE KEYS */;
/*!40000 ALTER TABLE `uc_docente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uc_horario`
--

DROP TABLE IF EXISTS `uc_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uc_horario` (
  `hor_id` int(10) NOT NULL,
  `uc_id` int(10) NOT NULL,
  `hor_dia` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado') NOT NULL,
  `hor_horainicio` varchar(5) NOT NULL,
  `hor_horafin` varchar(5) NOT NULL,
  PRIMARY KEY (`hor_id`,`uc_id`),
  KEY `uc_id` (`uc_id`),
  CONSTRAINT `uc_horario_ibfk_1` FOREIGN KEY (`hor_id`) REFERENCES `tbl_horario` (`hor_id`),
  CONSTRAINT `uc_horario_ibfk_2` FOREIGN KEY (`uc_id`) REFERENCES `tbl_uc` (`uc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uc_horario`
--

LOCK TABLES `uc_horario` WRITE;
/*!40000 ALTER TABLE `uc_horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `uc_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uc_pensum`
--

DROP TABLE IF EXISTS `uc_pensum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uc_pensum` (
  `uc_id` int(10) NOT NULL,
  `mal_id` int(10) NOT NULL,
  PRIMARY KEY (`uc_id`,`mal_id`),
  KEY `mal_id` (`mal_id`),
  CONSTRAINT `uc_pensum_ibfk_1` FOREIGN KEY (`uc_id`) REFERENCES `tbl_uc` (`uc_id`),
  CONSTRAINT `uc_pensum_ibfk_2` FOREIGN KEY (`mal_id`) REFERENCES `tbl_malla` (`mal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uc_pensum`
--

LOCK TABLES `uc_pensum` WRITE;
/*!40000 ALTER TABLE `uc_pensum` DISABLE KEYS */;
INSERT INTO `uc_pensum` VALUES (2,1);
/*!40000 ALTER TABLE `uc_pensum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_orgdocente'
--

--
-- Dumping routines for database 'db_orgdocente'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-20  0:09:04
